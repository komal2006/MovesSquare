package com.advancedandroidbook.simpleopengl2;

public class SimpleOpenGL2MenuActivity extends MenuActivity {

	@Override
	void prepareMenu() {
		addMenuItem("1. OpenGL ES 2 Intro", AndroidGL2Activity.class);

	}
}