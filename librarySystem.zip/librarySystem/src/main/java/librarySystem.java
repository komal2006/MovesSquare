import java.util.*;   //this is important for reading from keyboard
public class librarySystem {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("how many books you want to enter?");
        int size = sc.nextInt();
        String bookTitle[] = new String[size]; //create the array
        int noOfCopies[] = new int[size];  //create the array
        for (int i = 0; i < size; i++) {
            System.out.println("----------------------------------------------");
            System.out.println("Enter the title of book:");
            bookTitle[i] = sc.next();
            System.out.println("Enter the number of available copies of book:");
            noOfCopies[i] = sc.nextInt();
        }
        noAvailableCopies(bookTitle, noOfCopies, size); // calling method
        int co = noOfAvailableCopies(noOfCopies, size);
        System.out.println("----------------------------------------------");
        System.out.println("number of books with copies less than five: " + "  " + co);
        System.out.println("----------------------------------------------");
        int choice;
        choice = showMenu();
        switch (choice) {
            case 1:
                borrowBook(bookTitle, noOfCopies, size);
                break;
            case 2:
                returnBook(bookTitle, noOfCopies, size);
                break;

            default:
                System.out.println("Sorry!! please select from available options");
        }  //end of switch
    } // end of main method

    public static int noOfAvailableCopies(int noOfCopies[], int size) {
        int n = 0;
        for (int i = 0; i < size; i++)
            if (noOfCopies[i] < 5)
                n++;
        return n;
    }

    public static void noAvailableCopies(String bookTitle[], int noOfCopies[], int size) {
        for (int i = 0; i < size; i++)
            if (noOfCopies[i] == 0)
                System.out.println("Books having no available Copies are:" + "  " + bookTitle[i]);
    }

    public static int showMenu() {
        Scanner sc = new Scanner(System.in);
        System.out.println("************* Select an option *************");
        System.out.println("1:Borrow a book\n2:return a book");
        int choice = sc.nextInt();
        return choice;
    }

    //method of borrow the books
    public static void borrowBook(String bookTitle[], int noOfCopies[], int size) {
        Scanner sc = new Scanner(System.in);
        for (int i = 0; i < size; i++) {
            System.out.println((i + 1) + "  " + bookTitle[i]);
        }
        System.out.println(" Enter the book title you want to borrow:");
        String requestedBook;
        requestedBook = sc.next();
        int i;
        for (i = 0; i < size; i++)
            if (bookTitle[i].equalsIgnoreCase(requestedBook)) {
                if (!(noOfCopies[i] <= 0)) {
                    System.out.println("number of available copies for this book was :" + noOfCopies[i]);
                    noOfCopies[i] = noOfCopies[i] - 1;
                    System.out.println("You are borrowing " + bookTitle[i]);
                    System.out.println("Number of copies available is " + noOfCopies[i]);
                } else {
                    System.out.println("Sorry !! this book is not Available");
                }
            }
    }

    //method of return the books
    public static void returnBook(String title[], int noOfCopies[], int size) {
        Scanner sc = new Scanner(System.in);
        for (int i = 0; i < size; i++) {
            System.out.println((i + 1) + "  " + title[i]);
        }
        System.out.println(" Enter the book title you want to Return");
        String returnedBook = sc.next();
        int i;
        for (i = 0; i < size; i++)
            if (title[i].equalsIgnoreCase(returnedBook)) {
                System.out.println("number of available copies for this book:" + noOfCopies[i]);
                noOfCopies[i] = noOfCopies[i] + 1;
                System.out.println("book you are returning: " + title[i]);
                System.out.println("Now Number of copies available is: " + noOfCopies[i]);
            }
    }//end of returnBook Method

}
